# XML_PROJECT
Xml project for rendering xml content in browser.
